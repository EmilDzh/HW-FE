'use strict';

//1. В js объявлен массив с ссылками на картинки. На основе этого массива 
//формируется множество маленьких картинок в верхней части интерфейса. 
//При нажатии на одну из картинок забирается ссылка на эту картинку и 
//в нижней части интерфейса отображается в большем размере. Так, 
//пользователь нажимая на маленькие картинки видит их отображение в большем размере.


const pictureLinks = [
    'https://cdn.forestresearch.gov.uk/2021/11/forestry-home-1.jpg',
'https://www.travelandleisure.com/thmb/PtkzpF17oxHfxuTbsnUx7oJY20A=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/lake-tahoe-california-USLAKES0920-59df9ea26eaf4bbba7620eb604f0af3c.jpg',
'https://i.natgeofe.com/n/c9107b46-78b1-4394-988d-53927646c72b/1095.jpg',
'https://images.pexels.com/photos/618833/pexels-photo-618833.jpeg?cs=srgb&dl=pexels-sagui-andrea-618833.jpg&fm=jpg',
'https://www.timeforkids.com/wp-content/uploads/2021/07/turtle1.jpg'
];

const body = document.querySelector('body');
const bigImageContainer = document.querySelector('#bigImageContainer');

function showBigImage(link) {
  const bigImage = document.createElement('img');
  bigImage.src = link;
  bigImageContainer.innerHTML = '';
  bigImageContainer.appendChild(bigImage);
}

for (let i = 0; i < pictureLinks.length; i++) {
  const imageButton = document.createElement('button');

  imageButton.classList.add('image-button');

  imageButton.style.backgroundImage = `url("${pictureLinks[i]}")`;
  imageButton.style.width = '50px';
  imageButton.style.height = '50px';

  imageButton.addEventListener('click', function () {
    showBigImage(pictureLinks[i]);
  });

  body.append(imageButton);
} 

//пришлось закаментить так как на 2 странице в консоль выходить ощибка на 66 строке((

//Написать программу, которая формирует на основе массива строк
// множество параграфов и выводит их в интерфейс. При клике на 
//парагараф текст должен меняться на звездочки.
// Часть со *:  cделать процесс обратимым при повторном кликe.

// const strings = ['Hello', 'it', 'is', 'String', 'of', 'Array'];
// const prg = document.querySelector('#Prg');

// for (let i = 0; i < strings.length; i++) {
//     const paragraph = document.createElement('p');
//     paragraph.textContent = strings[i];

//     paragraph.addEventListener('click', () => {
//         if (paragraph.textContent === strings[i]) {
//             paragraph.textContent = '*'.repeat(strings[i].length);
//         } else {
//             paragraph.textContent = strings[i];
//         }
//     });

//     prg.append(paragraph);
// }

// Написать процесс для вывода информации на html-страницу.
// У нас есть книжный магазин. 
// В структуре проекта есть 2 html-страницы: index.html и books.html.
// На страницах в “шапке” есть навигационное меню, при помощи которого можно переходить между страничками.
// Страница index описывает наш магазин и приветствует пользователя.
// Страница books представляет собой набор карточек. Каждая карточка должна включать в себя:




// Заголовок 2 порядка

// Заголовок 3 порядка

// Параграф

// Изображение

// Спан


// При переходе на страницу должно отображаться 5 книг + кнопка “Загрузить еще”.
//  Все карточки книг должны формироваться динамически в js. В скрипте Вам нужно создать
//   массив на 10-12 товаров, по клику на кнопку “Загрузить еще” “подгружается” по 5 новых книг.


// В скрипте обязательно должно быть следующее:


// Каждая модель книги представляет из себя набор данных:



// id

// Заголовок

// Автор

// Короткое описание

// Фотография

// Стоимость


// 1) Необходимо вывести карточки для первых 5 книг
// 2) Для каждой карточки нужно вывести из массива наших книг все данные.
// 3) При нажатии на кнопку “Загрузить еще” должны формироваться новые элементы и подгружаться на страницу


// В этой задаче отрабатываем все - функции, циклы, массивы и объекты, 
// создание элементов, работу с атрибутами и "прослушку" ивентов. 
// Не пугайтесь ее (задача большая) - разбивайте на кусочки и по-этапно рассуждайте,
//  что нужно для чего. Удачи!


const dataBooks = [
    {
        id: 1, 
        title: 'Книга: 1',
        author: 'Автор: 1',
        description: 'Описание: 1',
        image: 'https://n1s1.hsmedia.ru/c0/f3/11/c0f3118d2a80f0f62409e68ccefab345/728x542_1_390d29f38af62661e1e5cd685acda5a2@1000x745_0xac120003_18591848241576673801.jpg', 
        price: 10

    },
    {
        id: 2, 
        title: 'Книга: 2',
        author: 'Автор: 2',
        description: 'Описание: 2',
        image: 'https://online-knigi.com/images/blog/32/chitat-knigi.jpg', 
        price: 15

    },
    {
        id: 3, 
        title: 'Книга: 3',
        author: 'Автор: 3',
        description: 'Описание: 3',
        image: 'https://booksonline.com.ua/blog/wp-content/uploads/2016/06/6-6-3.jpg', 
        price: 20

    }, {
        id: 4, 
        title: 'Книга: 4',
        author: 'Автор: 4',
        description: 'Описание: 4',
        image: 'https://say-hi.me/wp-content/uploads/2016/06/5-knig.jpg', 
        price: 25

    }, 
    {
        id: 5, 
        title: 'Книга: 5',
        author: 'Автор: 5',
        description: 'Описание: 5',
        image: 'https://nefakt.info/wp-content/uploads/2019/02/unnamed-file.jpg', 
        price: 30

    },
    {
        id: 6, 
        title: 'Книга: 6',
        author: 'Автор: 6',
        description: 'Описание: 6',
        image: 'https://lomonosovdezurnyj.files.wordpress.com/2018/07/kniga.jpg', 
        price: 35

    },
    {
        id: 7, 
        title: 'Книга: 7',
        author: 'Автор: 7',
        description: 'Описание: 7',
        image: 'https://www.belykrolik.ru/media/images/spisok-knig-dlia-chteniia.width-800.jpg', 
        price: 40

    },
    {
        id: 8, 
        title: 'Книга: 8',
        author: 'Автор: 8',
        description: 'Описание: 8',
        image: 'https://stihi.ru/pics/2019/06/26/689.jpg', 
        price: 45

    },
    {
        id: 9, 
        title: 'Книга: 9',
        author: 'Автор: 9',
        description: 'Описание: 9',
        image: 'https://kartinkof.club/uploads/posts/2022-06/1656066526_11-kartinkof-club-p-kartinki-s-nadpisyu-ya-s-knigoi-otkrivayu-13.jpg', 
        price: 50

    },
    {
        id: 10, 
        title: 'Книга: 10',
        author: 'Автор: 10',
        description: 'Описание: 10',
        image: 'https://kartinkin.net/uploads/posts/2022-03/1647078006_1-kartinkin-net-p-kniga-i-pero-kartinki-1.jpg', 
        price: 55

    },
    {
        id: 11, 
        title: 'Книга: 11',
        author: 'Автор: 11',
        description: 'Описание: 11',
        image: 'https://avatars.mds.yandex.net/i?id=1ce79db6b6b656ae66fbe696ffe91efd77ca3ab0-7752085-images-thumbs&n=13', 
        price: 60

    },
    {
        id: 12, 
        title: 'Книга: 12',
        author: 'Автор: 12',
        description: 'Описание: 12',
        image: 'https://avatars.mds.yandex.net/i?id=78467f77d98a448e02e65f72d74980f421b653c4-7755899-images-thumbs&n=13', 
        price: 9

    },
];

function createBookCard (book){
  const card = document.createElement('div');
  card.classList.add('book-card');
  

  const title = document.createElement('h2');
  title.textContent = book.title;
  card.append(title);

  const author = document.createElement('h3');
  author.textContent = book.author;
  card.append(author);

  const description = document.createElement('p')
  description.textContent = book.description;
  card.append(description);

  const image = document.createElement('img');
  image.src = book.image;
  image.alt = book.title;
  card.append(image);

  const price = document.createElement('span');
  price.textContent = book.price;
  card.append('price', price);

  card.style.border = '1px solid rgba(0,0,0,3)';
  card.style.padding = '10px';
  card.style.marginBottom = '10px';
  card.style.display = 'flex';
  card.style.flexDirection = 'column';
  
  price.style.fontSize = '20px';
  title.style.fontSize = '20px';
  title.style.marginBottom = '5px';


  return card;


}

const booksContainer = document.querySelector('#booksContainer');
const loadMoreButton = document.querySelector('#loadMoreButton');

let onDisplay = 5; 

function bookOnDisplay (){
     for (let i = 0; i < onDisplay; i++) {
    if (i >= dataBooks.length) {
      loadMoreButton.style.display = 'none';
      break;
    }

    const book = dataBooks[i];
    const bookCard = createBookCard(book);
    booksContainer.append(bookCard);
  }
}
bookOnDisplay();

loadMoreButton.addEventListener('click', () => {
    booksContainer.innerHTML = '';
    onDisplay += 5;
    bookOnDisplay();
});