'use scrict';

//Вывод таблицы умножения для определенного числа в массив, 
//каждый элемент массива в виде:
// число * итератор = результат. Для формирования строки
// используйте интерполяцию.

let number = 2;
let iter = 1;
let arr = [];

while(iter <= 10){
let result = number * iter;
let print = `${number} * ${iter} = ${result}`;
arr.push(print);
iter++;
}
console.log(arr);

//Поиск первого положительного числа в массиве:
// есть массив чисел и нужно найти первое число, которое является положительным.

let arrNums = [-1, -2, -13, -8, 5, -6 , 9];
let i = 0;

while(i < arrNums.length){
    if(arrNums[i] > 0){
     console.log(arrNums[i])
     break;
    }
    i++;
}

//Генерация случайного пароля: есть некая константа, 
//которая отвечает за длину пароля. 
//Сгенерируйте рандомный пароль до указанной длины, используя Math.random:

const passL = +prompt("Введите длину");
let alphabet = 'abcdefghijklmnopqrstuvwxyz123456789';

let Password = '';

while(true){
    let randomIn = Math.floor(Math.random() * alphabet.length);
    let randomLetter = alphabet.charAt(randomIn);
    Password += randomLetter;
   if(passL <= Password.length){
     break;
   }
}
console.log(Password);

//Объединение элементов массива в строку при помощи конкатенации: есть массив 
//строк (например, список покупок) - необходимо вывести его в виде строки.

let List1 = ['Яблоки', 'Груши', 'Арбузы', 'Бананы', 'Ананасы'];
let String1 = '';

for(let i = 0; i < List1.length; i++){
    String1 += List1[i];
    if(i < List1.length){
        String1 += ', '
    }
}

console.log(String1);

//Поиск наибольшего числа в массиве

let ranNums = [3, 5, 9 ,6 ,12, 43, 5, 3, 12, 54, 99];
let hNum = 0;

for(let i = 0; i < ranNums.length; i++){
   if(ranNums[i] > hNum){
    hNum = ranNums[i];
   }
}
console.log(hNum);

//Переворот строки: есть некая константа,
// содержащая строку. Необходимо вывести строку наоборот, используя цикл for

const String2 = 'abcdef';
let reservedStr = '';

for(let i = String2.length-1; i >= 0; i--){
    reservedStr += String2.charAt(i);
}
console.log(reservedStr);

//Подсчет количества гласных букв в строке: есть строка и 
//массив гласных в алфавите (можно выбрать английский). 
//Необходимо посчитать, сколько раз встречаются гласные в этой строке. 
//Методы для решения этой задачи Вы найдете в файлике к уроку.

const letters = 'asdfgxcbcxcvbdqwerrowretuoyjnadf';
const vowelA  = ['a','e','i','o','u']


let counter = 0;

for(let i = 0; i < letters.length; i++){
    const letter = letters[i];
  if(vowelA.includes(letter)){
    counter++
  }

}
console.log(counter);


//Напишите функцию, которая принимает массив чисел и возвращает их сумму.

let a = [3, 4];
let b = [4, 4];

function getSumOfArr (arr1, arr2){

    let sum = 0;

    for(let i = 0 ; i < arr1.length; i++){
        sum += arr1[i];
    }

    for(let i = 0 ; i < arr2.length; i++){
        sum += arr2[i];
    }
    return sum;
}


let result = getSumOfArr(a,b);
console.log(result);

//Напишите функцию findMax, которая принимает массив чисел 
//и возвращает максимальное число из этого массива.

let array1 = [12, 3434, 451,];
let array2 = [2, 4, 4355, 321,];

function findMax (arr1, arr2){
    let maxNum = 0;

    for(let i = 0; i < arr1.length; i++){
        if( arr1[i] > maxNum){
            maxNum = arr1[i];
        }
    }

    for( let i = 0; i <arr2.length; i++){
        if( arr2[i] > maxNum){
            maxNum = arr2[i]
        }
    }

    return maxNum;

}

let maxNumber = findMax(array1,array2);
console.log(maxNumber);

//Напишите функцию reverseArray, которая принимает массив и 
//возвращает новый массив, в котором элементы идут в обратном порядке.

let arrr = ['a','b','c','d','e','f','g'];

function reverseArray(arr){
    let revLetter = [];
    for(let i = arr.length; i >= 0; i--){
        revLetter.push(arr[i]);
    }

    return revLetter;

}

let result1 =  reverseArray(arrr);
console.log(result1);

//Напишите функцию, которая принимает массив строк и возвращает новый массив, 
//содержащий только строки, начинающиеся с заданной буквы.

let arr2 = ['a','b', 2, 3, 'casd2323', 'g', 22, 'p' ];
let userIn = prompt("задайте букву");

function retNewStr(arr3){
    let arr4 = [];

    for(let i = 0 ; i < arr3.length; i++){
    if(typeof arr3[i] === 'string' && arr3[i].startsWith(userIn.toLowerCase())){
        arr4.push(arr3[i])
    }

    }
    return arr4;
}

let newStr1 = retNewStr(arr2);
console.log(newStr1);

//Напишите функцию, которая принимает число и возвращает его факториал.

let numF = 6;

function getFactorial(num1){
    if( numF === 0 || numF ===1){
        return 1;
    }
    let res = 1;
   for(let i = 2; i <= num1 ; i++){
      res *= i;
   }
   return res
}

let resul = getFactorial(numF);
console.log(`Факториал числа ${numF} равен ${resul}`)


//Напишите функцию, которая принимает число и возвращает "Fizz", 
//если число делится на 3, "Buzz", если число делится на 5, и "FizzBuzz",
// если число делится и на 3, и на 5. В остальных случаях вернуть само число.

let nuM = 3;

function getNum(numberr){
    if(numberr % 3 === 0){
        return "Fizz"
    } else if(numberr % 5 === 0){
        return "FizzBuzz"
    } else {
        return numberr
    }
}

let cons = getNum(nuM);
console.log(cons);

//Создайте функциональное выражение calculateCircleArea, 
//которое принимает объект circle с свойством radius и возвращает площадь круга.

let radius1 = 5;

let calculateCircleArea = function(radius){
    return Math.PI * radius * 2;
}

let area = calculateCircleArea(radius1);
console.log(area);

//Создайте функциональное выражение calculateAverageGrade, 
//которое принимает объект student с массивом оценок grades 
//и возвращает среднюю оценку студента 
//(попробуйте использовать reduce, описанный в файле предыдущего урока).

const student = {
    grades: [3, 2, 4, 5],
};

let calculateAverageGrade = function(student) {
    let sum = 0;
    let length = student.grades.length;

    for (let i = 0; i < length; i++) {
        sum += student.grades[i];
    }

    return sum / length;
};

console.log(calculateAverageGrade(student));

// // const student = {
//     grades: [3, 2, 4, 5],
// };

// let calculateAverageGrade = function(student){
//     const total = student.grades.reduce((acc, grade) => acc + grade, 0);
//     return sum / student.grades.length;
// }
// console.log(calculateAverageGrade(student));


//Создайте функциональное выражение getFullName, 
//которое принимает объект person с свойствами firstName 
//и lastName и возвращает полное имя.

const person = {
    firstName:"Ed",
    lastName: "Sheeran"
} 

let getFullName = function(fName, LName){
    let fullName = fName + " " + LName;
    return fullName;
}

let check = getFullName(person.firstName , person.lastName);
console.log(check);

//Создайте объект calculator с двумя свойствами operand1 и operand2, 
//и двумя методами: add и multiply. Метод add должен принимать два числа 
//и возвращать их сумму, а метод multiply должен принимать два числа и 
//возвращать их произведение.
function getMultiply (num5, num6){
        return num5 * num6;
}

const calculator = {
    operand1:0,
    operand2:0,
    add:function(num3, num4){
        return num3 + num4;
    },
    multiply: getMultiply
}

calculator.operand1 = 5;
calculator.operand2 = 3;

console.log(calculator.add(calculator.operand1, calculator.operand2));
console.log(calculator.multiply(calculator.operand1, calculator.operand2));
